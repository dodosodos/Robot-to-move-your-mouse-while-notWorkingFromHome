// Move the mouse across the screen as a sine wave.
const robot = require("robotjs");
const interval = (60000 * 5) - 10000;

setInterval(() => {
    var mouse = robot.getMousePos();
    robot.moveMouse(mouse.x+1, mouse.y);
    robot.moveMouse(mouse.x, mouse.y);
}, interval);